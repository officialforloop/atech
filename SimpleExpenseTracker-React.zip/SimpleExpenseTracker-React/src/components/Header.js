import React from 'react'

export const Header = () => {
  return (
    <h2><center>
      Simple Expense Tracker</center>
    </h2>
  )
}
